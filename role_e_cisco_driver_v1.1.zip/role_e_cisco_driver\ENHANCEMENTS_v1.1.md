# Cisco Driver v1.1: change log

**Scope of this contribution:** IP-blocking logic, prevention of duplicate blocking rules, temporary blocking and TTL expiry, rollback and recovery, and the user documentation for them.

**Contributor:** _(add your name / GitHub username)_

**Not changed:** the mock router (`mock_router/`), the RESTCONF client (`cisco_driver/restconf_client.py`), API communication and connection handling. `config.py` received only three new **optional** settings, and their defaults keep v1.0 behaviour.

Nothing was removed. All 96 v1.0 tests pass unchanged; 42 new tests were added (138 in total).

---

## 1. IP-blocking logic

| Change | Where |
|---|---|
| **Protected (never-block) list**, `BLOCK_PROTECTED`: gateway, DNS, SIEM, admin hosts or whole networks are refused before the router is contacted | `driver.py` `protected_by()`, `validation.py` `parse_networks()`, `config.py` |
| **Batch blocking**, `block_many()` / `block-many`: one alert with several IPs; de-duplicates, reports bad entries as `invalid` without stopping the batch, keeps every safety check per IP; `--file` input | `driver.py`, `cli.py` |
| **One-call status check**, `status()` / `status`: compares router and record, answers `blocked` / `blocked_foreign` / `drift` / `not_blocked`, with time remaining and protection | `driver.py`, `cli.py` |

## 2. Duplicate prevention

| Change | Where |
|---|---|
| **Cross-process lock** on `blocks.db.lock` (OS file lock, released automatically if a process crashes). It fixes a v1.0 race: two processes could pick the same sequence number, so one rule overwrote another, or the second process crashed with `IntegrityError` after writing. Verified by running the new race tests with the lock disabled: they fail; with the lock they pass. | `store.py` `exclusive()`, `driver.py` `_exclusive()` |
| Duplicate IPs inside one batch are blocked once | `driver.py` `block_many()` |
| Duplicate rule written by an interrupted process is removed by `recover()` | `driver.py` `_recover_one()` |
| `reconcile` reports IPs denied by more than one line; `--fix` never adds a second rule for an IP already denied by someone else | `driver.py` `reconcile()` |

## 3. Temporary blocking and TTL expiry

| Change | Where |
|---|---|
| **Lifetime cap** `BLOCK_MAX_LIFETIME` (default 7 days): repeated alerts can no longer keep an IP blocked for ever | `driver.py` `_refreshed_expiry()` |
| **Repeat-offender TTL** `BLOCK_REPEAT_FACTOR` (off by default): TTL × factor^(earlier blocks in 7 days), capped at `BLOCK_MAX_TTL` | `driver.py` `_escalate()`, `store.py` `count_previous()` |
| **`extend()` / `extend`**: push expiry later without touching the router; never shortens | `driver.py`, `cli.py` |
| `remaining_seconds` in `list` / `status` | `driver.py` |
| Failed removals counted (`attempts`, `last_error`); `ERROR` log after 5 attempts | `driver.py` `_remove()`, `store.py` `note_failure()` |
| Worker resolves interrupted writes each round; `health()` and Ctrl+C summary | `expiry_worker.py`, `cli.py` |

## 4. Rollback and recovery

| Change | Where |
|---|---|
| **Write-ahead journal**: block recorded as `pending` before the router write, `active` after verification | `driver.py` `_block_locked()`, `store.py` `add(status=)`, `activate()` |
| **Automatic undo** of a write that fails half-way (e.g. verification read fails after the write landed): no untracked rule is left behind. In v1.0 such a rule became "foreign" and was never removed. | `driver.py` `_compensate()` |
| **`recover()` / `recover`**: resolves writes interrupted by a crash; also runs automatically before any block/unblock of the same IP and in the worker | `driver.py` |
| **`reconcile()` / `reconcile [--fix]`**: router vs record report; `--fix` re-applies the driver's rules after a router restart, moves to a free sequence if the old one is taken, closes expired records, never touches foreign rules | `driver.py`, `cli.py` |
| **Rollback by alert**, `unblock_alert()` / `rollback-alert`, for false positives | `driver.py`, `cli.py` |
| **Emergency rollback**, `unblock_all()` / `rollback-all --yes`, optionally per device; ownership-aware | `driver.py`, `cli.py` |
| **`backup`** command: SQLite online backup + integrity check, never overwrites | `store.py` `backup()`, `cli.py` |
| **Schema migration**: v1.0 databases are upgraded in place (`attempts`, `last_error` columns) | `store.py` `_migrate()` |

## 5. Documentation, demo, tests

| Change | Where |
|---|---|
| New user-guide section §9 (all features, commands, outputs, safety rules, compatibility), plus 🆕-marked updates in §1–§8 | `CISCO_DRIVER_USER_GUIDE.md` |
| 10-step demonstration of the new features | `demo/enhancements_demo.py` |
| 42 new tests in 5 groups | `tests/test_enhancements.py` |
| New evidence; v1.0 evidence kept as the baseline | `evidence/v1.1/` |
| `.gitignore`: `*.db.lock`, `backups/` | `.gitignore` |

## Compatibility

- Same public API, commands, results and messages as v1.0. New statuses appear only from new calls (`extended`, `invalid`, `recovered`, `discarded`).
- After v1.1 has opened a `blocks.db`, v1.0 can no longer read it (two extra columns). Back it up before upgrading.
