"""Role E - Cisco driver.

Applies and removes temporary IP blocks on a Cisco IOS XE router using RESTCONF.

Main entry points:
    CiscoDriver.block(ip, device, ttl_seconds, alert_id, reason)
    CiscoDriver.unblock(ip, device)
    CiscoDriver.expire_due()

Added in v1.1:
    CiscoDriver.block_many(ips, device, ttl_seconds, alert_id, reason)
    CiscoDriver.status(ip, device)
    CiscoDriver.extend(ip, device, seconds)
    CiscoDriver.recover()
    CiscoDriver.reconcile(device, fix=False)
    CiscoDriver.unblock_alert(alert_id)
    CiscoDriver.unblock_all(device=None)
"""

from .driver import CiscoDriver, Result
from .restconf_client import DeviceUnreachable, RestconfClient, RestconfError
from .store import LockTimeout
from .validation import ValidationError

__all__ = [
    "CiscoDriver",
    "Result",
    "RestconfClient",
    "RestconfError",
    "DeviceUnreachable",
    "ValidationError",
    "LockTimeout",
]
__version__ = "1.1.0"
